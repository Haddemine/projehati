package gestionetudiants;


public class Date {

  private int jour,mois,annee;

  public Date(int j,int m,int a) {
    jour=j;
    mois=m;
    annee=a;
  }

  public int getJour(){
    return jour;
  }

  public int getMois(){
    return mois;
  }

  public int getAnnee(){
    return annee;
  }

}